package com.avinash.repository;
import org.springframework.data.repository.CrudRepository;
//repository that extends CrudRepository
import com.avinash.model.Books;
public interface BooksRepository extends CrudRepository<Books, Integer>
{
}
