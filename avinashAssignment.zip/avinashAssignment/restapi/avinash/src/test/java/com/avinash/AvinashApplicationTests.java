package com.avinash;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AvinashApplicationTests {

	@Test
	void contextLoads() {
	}

}
